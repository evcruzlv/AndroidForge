# Simulado Yara V7 — build pelo AndroidForge

Este projeto foi preparado para build em nuvem.

## Compatibilidade do projeto
- Android Gradle Plugin: 8.7.3
- Gradle recomendado: 8.9
- JDK: 17
- compileSdk / targetSdk: 35
- Módulo APK: `app`
- APK esperado: `app/build/outputs/apk/debug/app-debug.apk`

## AndroidForge
O AndroidForge detecta o projeto e escolhe a toolchain automaticamente. Envie o ZIP do projeto e use a variante `debug` ou `auto`.

## Alternativa: GitHub Actions
A V7 também inclui `.github/workflows/build-apk.yml`.
Depois de enviar os arquivos para um repositório GitHub, abra **Actions > Build Simulado Yara APK > Run workflow**.
No fim do build, baixe o artifact **SimuladoYara-V7-debug**.
