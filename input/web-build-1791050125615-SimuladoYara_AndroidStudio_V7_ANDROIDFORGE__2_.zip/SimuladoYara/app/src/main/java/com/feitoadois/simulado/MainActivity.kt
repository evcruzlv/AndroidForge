package com.feitoadois.simulado

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt


data class Question(
    val id: String,
    val number: Int,
    val text: String,
    val answer: Boolean,
    val source: String,
    val theme: String
)

data class AnsweredQuestion(val question: Question, val selected: Boolean)

data class HistoryItem(val date: String, val title: String, val total: Int, val hits: Int, val pct: Int)

class MainActivity : AppCompatActivity() {

    private lateinit var root: LinearLayout
    private var allQuestions = listOf<Question>()
    private var currentExam = listOf<Question>()
    private val answers = mutableMapOf<String, Boolean>()
    private var currentIndex = 0
    private var colaMode = false
    private var currentTitle = "Simulado"
    private val prefs by lazy { getSharedPreferences("simulado_yara", Context.MODE_PRIVATE) }

    private val blue = Color.rgb(30, 91, 170)
    private val blueDark = Color.rgb(17, 52, 102)
    private val blueSoft = Color.rgb(232, 240, 252)
    private val green = Color.rgb(35, 126, 79)
    private val red = Color.rgb(198, 57, 57)
    private val dark = Color.rgb(25, 35, 52)
    private val gray = Color.rgb(96, 108, 125)
    private val bg = Color.rgb(246, 248, 252)
    private val white = Color.WHITE
    private val gold = Color.rgb(205, 145, 35)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = blueDark
        window.navigationBarColor = bg
        allQuestions = loadQuestions()
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        setContentView(root)
        showHome()
    }

    private fun loadQuestions(): List<Question> {
        val raw = assets.open("questions.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Question(
                id = o.getString("id"),
                number = o.getInt("number"),
                text = o.getString("text"),
                answer = o.getBoolean("answer"),
                source = o.getString("source"),
                theme = o.optString("theme", "Conhecimentos Gerais")
            )
        }
    }

    private fun clear() = root.removeAllViews()

    private fun title(text: String, size: Float = 25f): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(dark)
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, 0, 0, dp(6))
    }

    private fun subtitle(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(gray)
        setLineSpacing(0f, 1.12f)
        setPadding(0, 0, 0, dp(14))
    }

    private fun sectionLabel(text: String): TextView = TextView(this).apply {
        this.text = text.uppercase()
        textSize = 11f
        setTextColor(gray)
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        letterSpacing = 0.08f
        setPadding(0, dp(12), 0, dp(7))
    }

    private fun rounded(fill: Int, radius: Int = 14, stroke: Int? = null): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radius).toFloat()
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun selectorAdapter(options: Array<String>): ArrayAdapter<String> = object : ArrayAdapter<String>(
        this, android.R.layout.simple_spinner_item, options
    ) {
        override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
            val view = super.getView(position, convertView, parent) as TextView
            styleSelectorText(view)
            return view
        }
        override fun getDropDownView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
            val view = super.getDropDownView(position, convertView, parent) as TextView
            styleSelectorText(view)
            view.setPadding(dp(14), dp(11), dp(14), dp(11))
            return view
        }
    }.also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }

    private fun styleSelectorText(view: TextView) {
        view.setTextColor(Color.WHITE)
        view.textSize = 14f
        view.gravity = Gravity.CENTER_VERTICAL
        view.setPadding(dp(14), dp(2), dp(14), dp(2))
        view.setBackgroundColor(blueDark)
    }

    private fun addSelector(spinner: Spinner, adapter: ArrayAdapter<String>) {
        spinner.adapter = adapter
        spinner.background = rounded(blueDark, 12)
        spinner.setPadding(dp(3), 0, dp(3), 0)
    }

    private fun contentScroll(content: LinearLayout): ScrollView = ScrollView(this).apply {
        isFillViewport = true
        addView(content, LinearLayout.LayoutParams(-1, -2))
    }

    private fun card(): MaterialCardView = MaterialCardView(this).apply {
        radius = dp(16).toFloat()
        cardElevation = dp(2).toFloat()
        setCardBackgroundColor(white)
        setContentPadding(dp(16), dp(15), dp(16), dp(15))
    }

    private fun actionButton(text: String, color: Int = blue, height: Int = 52, listener: () -> Unit): MaterialButton =
        MaterialButton(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(Color.WHITE)
            setBackgroundColor(color)
            cornerRadius = dp(12)
            minHeight = 0
            setOnClickListener { listener() }
        }

    private fun secondaryButton(text: String, listener: () -> Unit): MaterialButton =
        MaterialButton(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(blueDark)
            setBackgroundColor(white)
            cornerRadius = dp(12)
            strokeColor = android.content.res.ColorStateList.valueOf(Color.rgb(210, 219, 232))
            strokeWidth = dp(1)
            minHeight = 0
            setOnClickListener { listener() }
        }

    private fun sourcePool(source: String): List<Question> = when (source) {
        "Pré-avaliação" -> allQuestions.filter { it.source == source }
        "SENE 1 - Competência Técnica" -> allQuestions.filter { it.source == source }
        "Pré-Reunião SSA 2026" -> allQuestions.filter { it.source == source }
        "Capacitação Técnica - Avaliação 01 do Polo NED" -> allQuestions.filter { it.source == source }
        else -> allQuestions
    }

    private fun quantityOptionsFor(total: Int): Array<String> {
        val standard = listOf(10, 20, 40, 80, 100, 145, 160, 200, 225, 258, 300, 400, 483)
        val options = standard.filter { it <= total }.toMutableList()
        if (total > 0 && !options.contains(total)) options.add(total)
        return options.distinct().sorted().map(Int::toString).toTypedArray()
    }

    private fun showHome() {
        clear(); colaMode = false
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(22)) }

        val hero = card().apply { setCardBackgroundColor(blueDark); setContentPadding(dp(18), dp(18), dp(18), dp(18)) }
        val heroBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        heroBox.addView(TextView(this).apply { text = "S"; textSize = 42f; setTextColor(Color.WHITE); setTypeface(typeface, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER; setBackground(rounded(blue, 18)); setPadding(dp(13), 0, dp(13), 0) }, LinearLayout.LayoutParams(dp(62), dp(62)))
        heroBox.addView(TextView(this).apply { text = "SIMULADO YARA"; textSize = 22f; setTextColor(Color.WHITE); setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(0, dp(12), 0, dp(2)) })
        heroBox.addView(TextView(this).apply { text = "Estude • pratique • revise • evolua"; textSize = 13f; setTextColor(Color.rgb(205, 218, 239)) })
        hero.addView(heroBox)
        content.addView(hero, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(12) })

        val stats = card()
        val statsBox = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val totalAnswered = prefs.getInt("answered_total", 0)
        val totalHits = prefs.getInt("hits_total", 0)
        val wrongCount = getWrongIds().size
        val accuracy = if (totalAnswered == 0) 0 else (totalHits * 100.0 / totalAnswered).roundToInt()
        statsBox.addView(statBlock("$accuracy%", "aproveitamento", blue), LinearLayout.LayoutParams(0, -2, 1f))
        statsBox.addView(statBlock("$wrongCount", "para revisar", red), LinearLayout.LayoutParams(0, -2, 1f))
        statsBox.addView(statBlock("${allQuestions.size}", "questões", dark), LinearLayout.LayoutParams(0, -2, 1f))
        stats.addView(statsBox)
        content.addView(stats, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        content.addView(actionButton("▶  COMEÇAR SIMULADO", blue, 54) { showBankSelection() }, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(9) })
        content.addView(actionButton("🧠  ESTUDAR POR TEMA", Color.rgb(70, 86, 105), 50) { showThemeSelection() }, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(9) })

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(secondaryButton("🔴  Errei") { showWrongStudy() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        row1.addView(secondaryButton("⭐  Favoritas") { showFavorites() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(8) })
        content.addView(row1, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(8) })
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(secondaryButton("📚  Prova Cola") { showSelectionForCola() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        row2.addView(secondaryButton("📖  Estudo de Vendas") { showSalesStudy() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(8) })
        content.addView(row2, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(8) })
        content.addView(secondaryButton("📈  Histórico e desempenho") { showHistory() }, LinearLayout.LayoutParams(-1, dp(48)))

        content.addView(sectionLabel("Banco rápido"))
        val sourceSpinner = Spinner(this)
        val sources = arrayOf("Todas as questões", "Pré-avaliação", "SENE 1 - Competência Técnica", "Pré-Reunião SSA 2026", "Capacitação Técnica - Avaliação 01 do Polo NED")
        addSelector(sourceSpinner, selectorAdapter(sources))
        content.addView(sourceSpinner, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(7) })

        val quantitySpinner = Spinner(this)
        var quantities = quantityOptionsFor(allQuestions.size)
        addSelector(quantitySpinner, selectorAdapter(quantities))
        quantitySpinner.setSelection(quantities.indexOf("20").coerceAtLeast(0))
        content.addView(quantitySpinner, LinearLayout.LayoutParams(-1, dp(48)))
        val sourceCount = TextView(this).apply { textSize = 12f; setTextColor(gray); setPadding(dp(2), dp(5), 0, dp(2)) }
        content.addView(sourceCount)
        sourceSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val pool = sourcePool(sources[position]); quantities = quantityOptionsFor(pool.size)
                quantitySpinner.adapter = selectorAdapter(quantities)
                quantitySpinner.setSelection(quantities.indexOfFirst { it.toInt() >= 20 }.takeIf { it >= 0 } ?: quantities.lastIndex)
                sourceCount.text = "${pool.size} questões disponíveis neste banco"
            }
        }
        sourceCount.text = "${allQuestions.size} questões disponíveis no banco completo"

        content.addView(actionButton("CRIAR PROVA", blue, 54) {
            val source = sources[sourceSpinner.selectedItemPosition]
            val pool = sourcePool(source)
            val amount = quantitySpinner.selectedItem.toString().toInt().coerceAtMost(pool.size)
            currentTitle = source
            startExam(pool, amount, true, false)
        }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(9) })

        root.addView(contentScroll(content), LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun statBlock(value: String, label: String, color: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        addView(TextView(this@MainActivity).apply { text = value; textSize = 21f; setTextColor(color); setTypeface(typeface, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER })
        addView(TextView(this@MainActivity).apply { text = label; textSize = 11f; setTextColor(gray); gravity = Gravity.CENTER; setPadding(0, dp(3), 0, 0) })
    }

    private fun showBankSelection() {
        clear()
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(22)) }
        content.addView(title("Novo simulado"))
        content.addView(subtitle("Escolha o banco. A quantidade disponível é ajustada automaticamente para cada prova."))
        content.addView(sectionLabel("Banco de questões"))
        val sources = arrayOf("Todas as questões", "Pré-avaliação", "SENE 1 - Competência Técnica", "Pré-Reunião SSA 2026", "Capacitação Técnica - Avaliação 01 do Polo NED")
        val spinner = Spinner(this); addSelector(spinner, selectorAdapter(sources)); content.addView(spinner, LinearLayout.LayoutParams(-1, dp(50)))
        content.addView(sectionLabel("Quantidade"))
        val qty = Spinner(this); var options = quantityOptionsFor(allQuestions.size); addSelector(qty, selectorAdapter(options)); qty.setSelection(options.indexOf("20").coerceAtLeast(0)); content.addView(qty, LinearLayout.LayoutParams(-1, dp(50)))
        val count = TextView(this).apply { textSize = 12f; setTextColor(gray); setPadding(dp(2), dp(6), 0, dp(8)) }; content.addView(count)
        val shuffle = CheckBox(this).apply { text = "Embaralhar questões"; isChecked = true; setTextColor(dark) }; content.addView(shuffle)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val pool = sourcePool(sources[position]); options = quantityOptionsFor(pool.size); qty.adapter = selectorAdapter(options); qty.setSelection(options.indexOfFirst { it.toInt() >= 20 }.takeIf { it >= 0 } ?: options.lastIndex); count.text = "${pool.size} questões disponíveis"
            }
        }
        count.text = "${allQuestions.size} questões disponíveis"
        content.addView(actionButton("COMEÇAR PROVA", blue, 54) { val source = sources[spinner.selectedItemPosition]; currentTitle = source; startExam(sourcePool(source), qty.selectedItem.toString().toInt(), shuffle.isChecked, false) }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(12) })
        content.addView(secondaryButton("VOLTAR") { showHome() }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(9) })
        root.addView(contentScroll(content), LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun getThemes(): List<String> = listOf("Todos os temas") + allQuestions.map { it.theme }.distinct().sorted()
    private fun getThemePool(theme: String): List<Question> = if (theme == "Todos os temas") allQuestions else allQuestions.filter { it.theme == theme }

    private fun showThemeSelection() {
        clear()
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(22)) }
        content.addView(title("Estudar por tema"))
        content.addView(subtitle("Monte uma prova focada em um único assunto."))
        content.addView(sectionLabel("Tema"))
        val themes = getThemes().toTypedArray(); val themeSpinner = Spinner(this); addSelector(themeSpinner, selectorAdapter(themes)); content.addView(themeSpinner, LinearLayout.LayoutParams(-1, dp(50)))
        val available = TextView(this).apply { textSize = 12f; setTextColor(gray); setPadding(dp(2), dp(6), 0, dp(4)) }; content.addView(available)
        content.addView(sectionLabel("Quantidade"))
        val qty = Spinner(this); var options = quantityOptionsFor(allQuestions.size); addSelector(qty, selectorAdapter(options)); qty.setSelection(0); content.addView(qty, LinearLayout.LayoutParams(-1, dp(50)))
        themeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { val pool = getThemePool(themes[position]); options = quantityOptionsFor(pool.size); qty.adapter = selectorAdapter(options); available.text = "${pool.size} questões neste tema" }
        }
        available.text = "${allQuestions.size} questões disponíveis"
        content.addView(actionButton("COMEÇAR POR TEMA", blue, 54) { val theme = themes[themeSpinner.selectedItemPosition]; currentTitle = theme; startExam(getThemePool(theme), qty.selectedItem.toString().toInt(), true, false) }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(12) })
        content.addView(secondaryButton("VOLTAR") { showHome() }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(9) })
        root.addView(contentScroll(content), LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun showSelectionForCola() {
        clear(); val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(22)) }
        content.addView(title("Prova Cola")); content.addView(subtitle("Modo de estudo: toque na questão para revelar a resposta."))
        content.addView(sectionLabel("Banco"))
        val sources = arrayOf("Todas as questões", "Pré-avaliação", "SENE 1 - Competência Técnica", "Pré-Reunião SSA 2026", "Capacitação Técnica - Avaliação 01 do Polo NED")
        val spinner = Spinner(this); addSelector(spinner, selectorAdapter(sources)); content.addView(spinner, LinearLayout.LayoutParams(-1, dp(50)))
        content.addView(sectionLabel("Quantidade")); val qty = Spinner(this); var options = quantityOptionsFor(allQuestions.size); addSelector(qty, selectorAdapter(options)); content.addView(qty, LinearLayout.LayoutParams(-1, dp(50)))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener { override fun onNothingSelected(p: AdapterView<*>?) {}; override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { options = quantityOptionsFor(sourcePool(sources[pos]).size); qty.adapter = selectorAdapter(options); qty.setSelection(0) } }
        content.addView(actionButton("ABRIR PROVA COLA", blueDark, 54) { currentTitle = "Prova Cola"; startExam(sourcePool(sources[spinner.selectedItemPosition]), qty.selectedItem.toString().toInt(), true, true) }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(12) })
        content.addView(secondaryButton("VOLTAR") { showHome() }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(9) })
        root.addView(contentScroll(content), LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun startExam(poolInput: List<Question>, requested: Int, shuffle: Boolean, cola: Boolean) {
        var pool = poolInput
        if (shuffle) pool = pool.shuffled()
        currentExam = pool.take(requested.coerceAtMost(pool.size))
        answers.clear(); currentIndex = 0; colaMode = cola
        if (colaMode) showCola() else showQuestion()
    }

    private fun showQuestion() {
        clear(); val q = currentExam[currentIndex]; val selected = answers[q.id]
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(22)) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply { text = "${currentIndex + 1}/${currentExam.size}"; textSize = 14f; setTextColor(blue); setTypeface(typeface, android.graphics.Typeface.BOLD) }, LinearLayout.LayoutParams(0, -2, 1f))
        val fav = MaterialButton(this).apply { text = if (isFavorite(q.id)) "★" else "☆"; textSize = 22f; setTextColor(if (isFavorite(q.id)) gold else gray); setBackgroundColor(Color.TRANSPARENT); minHeight = 0; setPadding(0,0,0,0); setOnClickListener { toggleFavorite(q.id); text = if (isFavorite(q.id)) "★" else "☆"; setTextColor(if (isFavorite(q.id)) gold else gray) } }
        top.addView(fav, LinearLayout.LayoutParams(dp(52), dp(44)))
        content.addView(top)
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = currentExam.size; progress = currentIndex + 1 }; content.addView(bar, LinearLayout.LayoutParams(-1, dp(8)).apply { topMargin = dp(5); bottomMargin = dp(14) })
        content.addView(TextView(this).apply { text = "${q.source}  •  ${q.theme}"; textSize = 11.5f; setTextColor(gray); setPadding(0,0,0,dp(9)) })
        val qCard = card(); qCard.setContentPadding(dp(17), dp(19), dp(17), dp(19)); qCard.addView(TextView(this).apply { text = q.text; textSize = 18f; setTextColor(dark); setLineSpacing(0f,1.16f) }); content.addView(qCard)
        val trueBtn = answerButton("VERDADEIRO", green, selected == true) { answerCurrent(true) }
        val falseBtn = answerButton("FALSO", red, selected == false) { answerCurrent(false) }
        content.addView(trueBtn, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(17) }); content.addView(falseBtn, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(9) })
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val previous = secondaryButton("← ANTERIOR") { if (currentIndex > 0) { currentIndex--; showQuestion() } }; previous.isEnabled = currentIndex > 0
        nav.addView(previous, LinearLayout.LayoutParams(0, dp(50), 1f))
        val next = actionButton(if (currentIndex == currentExam.lastIndex) "FINALIZAR" else "PRÓXIMA →", blue, 50) { if (answers.containsKey(q.id)) { if (currentIndex == currentExam.lastIndex) showResult() else { currentIndex++; showQuestion() } } else Toast.makeText(this,"Selecione Verdadeiro ou Falso.",Toast.LENGTH_SHORT).show() }
        nav.addView(next, LinearLayout.LayoutParams(0, dp(50), 1f).apply { leftMargin = dp(8) }); content.addView(nav, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(14) })
        content.addView(secondaryButton("Encerrar simulado") { AlertDialog.Builder(this).setTitle("Encerrar agora?").setMessage("O resultado será calculado com as questões já respondidas.").setNegativeButton("Continuar",null).setPositiveButton("Encerrar") { _,_-> showResult() }.show() }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(8) })
        root.addView(contentScroll(content), LinearLayout.LayoutParams(-1,0,1f))
    }

    private fun answerButton(text: String, color: Int, selected: Boolean, action: () -> Unit) = MaterialButton(this).apply { this.text = if (selected) "✓ $text" else text; textSize = 15f; setTextColor(Color.WHITE); setBackgroundColor(color); cornerRadius = dp(12); alpha = if (selected) 1f else .9f; minHeight=0; setOnClickListener{action()} }

    private fun answerCurrent(selected: Boolean) { answers[currentExam[currentIndex].id] = selected; if (currentIndex < currentExam.lastIndex) { currentIndex++; showQuestion() } else showResult() }

    private fun showCola() {
        clear(); val content = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(14),dp(14),dp(18)) }
        content.addView(title("Prova Cola")); content.addView(subtitle("Toque em cada cartão para revelar a resposta."))
        val scroll=ScrollView(this); val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        currentExam.forEachIndexed { i,q ->
            val c=card(); val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
            box.addView(TextView(this).apply{text="${i+1}. ${q.text}";textSize=15.5f;setTextColor(dark);setTypeface(typeface,android.graphics.Typeface.BOLD);setLineSpacing(0f,1.12f)})
            val hint=TextView(this).apply{text="Toque para revelar ▾";textSize=12f;setTextColor(blue);setPadding(0,dp(9),0,0)}
            val ans=TextView(this).apply{text="RESPOSTA: ${if(q.answer)"VERDADEIRO" else "FALSO"}\n\n${q.source} • ${q.theme}";textSize=13.5f;setTextColor(green);setTypeface(typeface,android.graphics.Typeface.BOLD);setPadding(0,dp(10),0,0);visibility=View.GONE}
            box.addView(hint);box.addView(ans);c.addView(box);c.setOnClickListener{val open=ans.visibility!=View.VISIBLE;ans.visibility=if(open)View.VISIBLE else View.GONE;hint.text=if(open)"Toque para ocultar ▴" else "Toque para revelar ▾"};list.addView(c,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(9)})
        }
        scroll.addView(list);content.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));content.addView(actionButton("VOLTAR",blue,50){showHome()},LinearLayout.LayoutParams(-1,dp(50)).apply{topMargin=dp(9)});root.addView(content,LinearLayout.LayoutParams(-1,0,1f))
    }

    private fun showResult() {
        val answered=currentExam.mapNotNull{q->answers[q.id]?.let{AnsweredQuestion(q,it)}};val total=answered.size;val hits=answered.count{it.selected==it.question.answer};val misses=total-hits;val pct=if(total==0)0 else(hits*100.0/total).roundToInt()
        savePerformance(total,hits,answered);clear();val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(22))}
        content.addView(title("Resultado"));content.addView(subtitle("$currentTitle  •  $total questão(ões) respondida(s)"))
        val metrics=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};metrics.addView(metricCard("$hits","Acertos",green),LinearLayout.LayoutParams(0,dp(92),1f));metrics.addView(metricCard("$misses","Erros",red),LinearLayout.LayoutParams(0,dp(92),1f).apply{leftMargin=dp(6)});metrics.addView(metricCard("$pct%","Aproveitamento",blue),LinearLayout.LayoutParams(0,dp(92),1f).apply{leftMargin=dp(6)});content.addView(metrics)
        content.addView(TextView(this).apply{text=when{pct>=90->"Excelente resultado. Continue revisando os pontos fracos.";pct>=75->"Bom resultado. Revise os erros antes de refazer.";pct>=60->"Você está avançando. Use a revisão para consolidar.";else->"Use a revisão dos erros e faça uma nova tentativa."};textSize=15f;setTextColor(dark);gravity=Gravity.CENTER;setPadding(dp(4),dp(15),dp(4),dp(15))})
        if(misses>0)content.addView(actionButton("🔴  REVISAR ERROS",red,52){showReview()},LinearLayout.LayoutParams(-1,dp(52)).apply{bottomMargin=dp(8)})
        content.addView(actionButton("🔄  REFAZER SIMULADO",blue,52){answers.clear();currentIndex=0;currentExam=currentExam.shuffled();showQuestion()},LinearLayout.LayoutParams(-1,dp(52)).apply{bottomMargin=dp(8)})
        content.addView(actionButton("📚  ABRIR PROVA COLA",blueDark,52){showCola()},LinearLayout.LayoutParams(-1,dp(52)).apply{bottomMargin=dp(8)})
        content.addView(secondaryButton("NOVO SIMULADO"){showHome()},LinearLayout.LayoutParams(-1,dp(50)))
        root.addView(contentScroll(content),LinearLayout.LayoutParams(-1,0,1f))
    }

    private fun metricCard(value:String,label:String,color:Int):MaterialCardView{val c=card();val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER};box.addView(TextView(this@MainActivity).apply{text=value;textSize=21f;setTextColor(color);setTypeface(typeface,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER});box.addView(TextView(this@MainActivity).apply{text=label;textSize=11f;setTextColor(gray);gravity=Gravity.CENTER;setPadding(0,dp(3),0,0)});c.addView(box);return c}

    private fun showReview(){
        val wrong=currentExam.mapNotNull{q->answers[q.id]?.let{if(it!=q.answer)AnsweredQuestion(q,it)else null}}
        showQuestionList("Revisão dos erros","${wrong.size} questão(ões) erradas nesta prova.",wrong.map{it.question})
    }

    private fun showWrongStudy(){
        val ids=getWrongIds();val qs=allQuestions.filter{ids.contains(it.id)}
        if(qs.isEmpty()){AlertDialog.Builder(this).setTitle("Sem questões para revisar").setMessage("Você ainda não acumulou questões erradas.").setPositiveButton("OK",null).show();return}
        showQuestionList("Questões para revisar","Estas questões foram erradas em provas anteriores.",qs)
    }

    private fun showFavorites(){
        val ids=getFavoriteIds();val qs=allQuestions.filter{ids.contains(it.id)}
        if(qs.isEmpty()){AlertDialog.Builder(this).setTitle("Nenhuma favorita").setMessage("Durante uma prova, toque na estrela para guardar uma questão.").setPositiveButton("OK",null).show();return}
        showQuestionList("Minhas favoritas","${qs.size} questão(ões) marcadas.",qs)
    }

    private fun showQuestionList(head:String,sub:String,questions:List<Question>){
        clear();val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(14),dp(14),dp(18))};content.addView(title(head));content.addView(subtitle(sub));val scroll=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        questions.forEachIndexed{i,q->val c=card();val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};box.addView(TextView(this).apply{text="${i+1}. ${q.text}";textSize=15f;setTextColor(dark);setTypeface(typeface,android.graphics.Typeface.BOLD);setLineSpacing(0f,1.12f)});box.addView(TextView(this).apply{text="Resposta: ${if(q.answer)"VERDADEIRO" else "FALSO"}";textSize=13f;setTextColor(green);setTypeface(typeface,android.graphics.Typeface.BOLD);setPadding(0,dp(10),0,dp(3))});box.addView(TextView(this).apply{text="${q.source} • ${q.theme}";textSize=11.5f;setTextColor(gray)});c.addView(box);list.addView(c,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(9)})};scroll.addView(list);content.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));content.addView(actionButton("VOLTAR",blue,50){showHome()},LinearLayout.LayoutParams(-1,dp(50)).apply{topMargin=dp(9)});root.addView(content,LinearLayout.LayoutParams(-1,0,1f))
    }

    private fun showHistory(){
        clear();val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(22))};content.addView(title("Histórico e desempenho"));content.addView(subtitle("Acompanhe sua evolução nas provas realizadas neste aparelho."))
        val total=prefs.getInt("answered_total",0);val hits=prefs.getInt("hits_total",0);val pct=if(total==0) 0 else (hits*100.0/total).roundToInt();val overview=card();val overviewBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER};overviewBox.addView(TextView(this).apply{text="$pct%";textSize=32f;setTextColor(blue);setTypeface(typeface,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER});overviewBox.addView(TextView(this).apply{text="aproveitamento geral";textSize=12f;setTextColor(gray);gravity=Gravity.CENTER;setPadding(0,dp(2),0,0)});overview.addView(overviewBox,LinearLayout.LayoutParams(-1,-1));content.addView(overview,LinearLayout.LayoutParams(-1,dp(92)).apply{bottomMargin=dp(12)})
        content.addView(sectionLabel("Últimas provas"));val history=loadHistory();if(history.isEmpty())content.addView(TextView(this).apply{text="Nenhuma prova registrada ainda.";textSize=14f;setTextColor(gray);setPadding(0,dp(10),0,dp(20))}) else history.take(15).forEach{h->val c=card();val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL};val info=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};info.addView(TextView(this@MainActivity).apply{text=h.title;textSize=14f;setTextColor(dark);setTypeface(typeface,android.graphics.Typeface.BOLD)});info.addView(TextView(this@MainActivity).apply{text="${h.date}  •  ${h.total} questões";textSize=11.5f;setTextColor(gray);setPadding(0,dp(4),0,0)});row.addView(info,LinearLayout.LayoutParams(0,-2,1f));row.addView(TextView(this).apply{text="${h.pct}%\n${h.hits}/${h.total}";textSize=14f;setTextColor(if(h.pct>=75)green else red);setTypeface(typeface,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER});c.addView(row);content.addView(c,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(8)})}
        content.addView(secondaryButton("VOLTAR"){showHome()},LinearLayout.LayoutParams(-1,dp(50)).apply{topMargin=dp(8)});root.addView(contentScroll(content),LinearLayout.LayoutParams(-1,0,1f))
    }

    private fun showSalesStudy(){
        clear();val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(14),dp(14),dp(20))};content.addView(title("Estudo de Vendas"));content.addView(subtitle("SPIN Selling, EPA e OPC — resumo prático para revisão."))
        studyCard(content,"SPIN SELLING","Diagnóstico por perguntas","S — Situação","Entenda contexto, cenário e prioridades do cliente.","P — Problema","Explore dificuldades, insatisfações e obstáculos.","I — Implicação","Aprofunde as consequências do problema: impacto, risco, custo ou oportunidade perdida.","N — Need-payoff","Faça o cliente explicitar o valor de resolver o problema e os benefícios esperados.","Fonte: Huthwaite International, criadora da metodologia SPIN®.","https://www.huthwaiteinternational.com/spin-methodology")
        studyCard(content,"EPA","Diferenciação e condução da conversa","E — Educar","Traga uma perspectiva ou insight que ajude o cliente a enxergar uma oportunidade ou problema de outra forma.","P — Personalizar","Adapte a mensagem ao contexto, necessidade e papel de cada decisor.","A — Assumir o controle","Conduza o processo com firmeza e respeito, deixando próximos passos claros.","Fonte: Paixão por Vendas / modelo EPA associado ao Challenger Sales.","https://paixaoporvendas.com.br/metodologias/challenger-sales/")
        studyCard(content,"OPC","Preparação da reunião","O — Objetivos","Defina o que você precisa alcançar na reunião, além de simplesmente apresentar um produto.","P — Processo","Planeje como a conversa será conduzida: perguntas, diagnóstico, construção de valor e encaminhamento.","C — Compromissos","Defina quais próximos passos e compromissos você quer sair da reunião com o cliente.","Aplicação consultiva: o OPC é apresentado pela Paixão por Vendas como ferramenta de preparação de reuniões.","https://paixaoporvendas.com.br/metodologias/vendas-complexas/")
        val practice=card();practice.addView(TextView(this).apply{text="COMO USAR NO CAMPO";textSize=12f;setTextColor(blue);setTypeface(typeface,android.graphics.Typeface.BOLD)});practice.addView(TextView(this).apply{text="1. OPC antes da visita → 2. SPIN durante o diagnóstico → 3. EPA para construir e conduzir valor → 4. Próximo compromisso claro.";textSize=15f;setTextColor(dark);setLineSpacing(0f,1.16f);setPadding(0,dp(8),0,0)});content.addView(practice,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(9)})
        content.addView(actionButton("ABRIR FONTE: HUTHWAITE",blueDark,50){openUrl("https://www.huthwaiteinternational.com/spin-methodology")},LinearLayout.LayoutParams(-1,dp(50)).apply{bottomMargin=dp(8)});content.addView(secondaryButton("VOLTAR"){showHome()},LinearLayout.LayoutParams(-1,dp(50)));root.addView(contentScroll(content),LinearLayout.LayoutParams(-1,0,1f))
    }

    private fun studyCard(content:LinearLayout,heading:String,sub:String,vararg parts:String){
        val c=card()
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        box.addView(TextView(this).apply{text=heading;textSize=18f;setTextColor(blueDark);setTypeface(typeface,android.graphics.Typeface.BOLD)})
        box.addView(TextView(this).apply{text=sub;textSize=12f;setTextColor(gray);setPadding(0,dp(3),0,dp(8))})
        var i=0
        while(i+1<parts.size-2){
            box.addView(TextView(this).apply{text=parts[i];textSize=14f;setTextColor(dark);setTypeface(typeface,android.graphics.Typeface.BOLD);setPadding(0,dp(7),0,dp(2))})
            box.addView(TextView(this).apply{text=parts[i+1];textSize=13.5f;setTextColor(gray);setLineSpacing(0f,1.12f)})
            i+=2
        }
        if(parts.size>=2){
            val source=parts[parts.size-2]
            val url=parts.last()
            box.addView(TextView(this).apply{text=source;textSize=10.5f;setTextColor(gray);setPadding(0,dp(10),0,dp(4))})
            box.addView(TextView(this).apply{text="Abrir fonte ↗";textSize=12f;setTextColor(blue);setTypeface(typeface,android.graphics.Typeface.BOLD);setPadding(0,dp(2),0,0);setOnClickListener{openUrl(url)}})
        }
        c.addView(box)
        content.addView(c,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(9)})
    }

    private fun openUrl(url:String){try{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)))}catch(_:Exception){Toast.makeText(this,"Não foi possível abrir o navegador.",Toast.LENGTH_SHORT).show()}}

    private fun isFavorite(id:String)=getFavoriteIds().contains(id)
    private fun getFavoriteIds(): Set<String> =prefs.getStringSet("favorites",emptySet())?:emptySet()
    private fun toggleFavorite(id:String){val set=getFavoriteIds().toMutableSet();if(!set.add(id))set.remove(id);prefs.edit().putStringSet("favorites",set).apply()}
    private fun getWrongIds(): Set<String> =prefs.getStringSet("wrong_ids",emptySet())?:emptySet()

    private fun savePerformance(total:Int,hits:Int,answered:List<AnsweredQuestion>){
        if(total==0)return
        val wrong=getWrongIds().toMutableSet();answered.filter{it.selected!=it.question.answer}.forEach{wrong.add(it.question.id)};answered.filter{it.selected==it.question.answer}.forEach{wrong.remove(it.question.id)}
        prefs.edit().putStringSet("wrong_ids",wrong).putInt("answered_total",prefs.getInt("answered_total",0)+total).putInt("hits_total",prefs.getInt("hits_total",0)+hits).apply()
        val history=loadHistory().toMutableList();val date=java.text.SimpleDateFormat("dd/MM/yyyy HH:mm",java.util.Locale.getDefault()).format(java.util.Date());val pct=(hits*100.0/total).roundToInt();history.add(0,HistoryItem(date,currentTitle,total,hits,pct));saveHistory(history.take(30))
    }

    private fun loadHistory():List<HistoryItem>{val raw=prefs.getString("history","[]")?:"[]";return try{val arr=JSONArray(raw);(0 until arr.length()).map{val o=arr.getJSONObject(it);HistoryItem(o.getString("date"),o.getString("title"),o.getInt("total"),o.getInt("hits"),o.getInt("pct"))}}catch(_:Exception){emptyList()}}
    private fun saveHistory(items:List<HistoryItem>){val arr=JSONArray();items.forEach{arr.put(JSONObject().apply{put("date",it.date);put("title",it.title);put("total",it.total);put("hits",it.hits);put("pct",it.pct)})};prefs.edit().putString("history",arr.toString()).apply()}

    private fun dp(value:Int)= (value*resources.displayMetrics.density).roundToInt()

    @Deprecated("Deprecated in Java")
    override fun onBackPressed(){if(colaMode&&currentExam.isNotEmpty()){showHome();return};AlertDialog.Builder(this).setTitle("Voltar ao início?").setMessage("O simulado atual será encerrado.").setNegativeButton("Cancelar",null).setPositiveButton("Voltar"){_,_->showHome()}.show()}
}
