# Simulado Yara V7

Aplicativo Android offline de estudo e simulados com 483 questões.

## Recursos
- 4 bancos de questões + banco completo
- Quantidade de questões ajustada por banco
- Prova por tema
- Prova Cola
- Voltar para questão anterior
- Favoritas
- Revisão das erradas
- Histórico e desempenho
- Módulo de estudo de vendas: SPIN Selling, EPA e OPC
- Interface moderna e compacta para celular
- Ícone com a letra S

## Bancos
- Pré-avaliação: 145
- SENE 1 - Competência Técnica: 80
- Pré-Reunião SSA 2026: 160
- Capacitação Técnica - Avaliação 01 do Polo NED: 98
- Total: 483

## Build
- AGP 8.7.3
- Kotlin 2.0.21
- Java 17
- Gradle 8.9
- compileSdk 35 / targetSdk 35

Para build pelo celular/online, veja `ANDROIDFORGE.md`.
Também há um workflow GitHub Actions em `.github/workflows/build-apk.yml`.
